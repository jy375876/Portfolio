use bbs;

show tables;

create table MVCBOARD (
	BD_NO varchar(100) primary key,
	BD_NAME varchar(100) not null,
	BD_TITLE varchar(200) not null,
	BD_CONTENT varchar(4000) not null,
	BD_DATE DATE not null
);

insert into MVCBOARD values(1, "이름", "제목", "내용", curdate());

select * from MVCBOARD;