create database BBS;

create table user (
	userID varchar(20),
	userPassword VARCHAR(20),
	userName VARCHAR(20),
	userGender VARCHAR(20),
	userEmail VARCHAR(50),
	primary key (userID)
);

desc user;

select * from user;

insert into user values("main", "0322", "테스트", "여자", "test@mail.com");