
function showInfo()  {
  // 선택된 목록 가져오기
  const query = 'input[name="area"]:checked';
  const selectedEls = document.querySelectorAll(query);
  
  // 선택된 목록에서 value 찾기
  let result = '';
  
  selectedEls.forEach((el) => {
    result += el.value + ' ';
  });
  
  // 출력
  //document.getElementById('result').innerText= result;
  // 동적으로 seoul.jsp를 가져와서 출력
  if (result.includes('seoul')) {
    fetch('../festinfo/area/seoul.jsp')
      .then((response) => response.text())
      .then((data) => {
        document.getElementById('result').innerHTML = data;
      });
  } else if (result.includes('gyeonggi')) {
    fetch('../festinfo/area/gyeonggi.jsp')
      .then((response) => response.text())
      .then((data) => {
        document.getElementById('result').innerHTML = data;
      });
  } else if (result.includes('incheon')) {
    fetch('../festinfo/area/incheon.jsp')
      .then((response) => response.text())
      .then((data) => {
        document.getElementById('result').innerHTML = data;
      });
  } else if (result.includes('busan')) {
    fetch('../festinfo/area/busan.jsp')
      .then((response) => response.text())
      .then((data) => {
        document.getElementById('result').innerHTML = data;
      });
  } else if (result.includes('daegu')) {
    fetch('../festinfo/area/daegu.jsp')
      .then((response) => response.text())
      .then((data) => {
        document.getElementById('result').innerHTML = data;
      });
  } else if (result.includes('daegeon')) {
    fetch('../festinfo/area/daegeon.jsp')
      .then((response) => response.text())
      .then((data) => {
        document.getElementById('result').innerHTML = data;
      });
  } else if (result.includes('kwangju')) {
    fetch('../festinfo/area/kwangju.jsp')
      .then((response) => response.text())
      .then((data) => {
        document.getElementById('result').innerHTML = data;
      });
  } else if (result.includes('gangwon')) {
    fetch('../festinfo/area/gangwon.jsp')
      .then((response) => response.text())
      .then((data) => {
        document.getElementById('result').innerHTML = data;
      });
  } else if (result.includes('ulsan')) {
    fetch('../festinfo/area/ulsan.jsp')
      .then((response) => response.text())
      .then((data) => {
        document.getElementById('result').innerHTML = data;
      });
  } else if (result.includes('jeonnam')) {
    fetch('../festinfo/area/jeonnam.jsp')
      .then((response) => response.text())
      .then((data) => {
        document.getElementById('result').innerHTML = data;
      });
  } else if (result.includes('jeonbuk')) {
    fetch('../festinfo/area/jeonbuk.jsp')
      .then((response) => response.text())
      .then((data) => {
        document.getElementById('result').innerHTML = data;
      });
  } else if (result.includes('chungbuk')) {
    fetch('../festinfo/area/chungbuk.jsp')
      .then((response) => response.text())
      .then((data) => {
        document.getElementById('result').innerHTML = data;
      });
  } else if (result.includes('chungnam')) {
    fetch('../festinfo/area/chungnam.jsp')
      .then((response) => response.text())
      .then((data) => {
        document.getElementById('result').innerHTML = data;
      });
  } else if (result.includes('jeju')) {
    fetch('../festinfo/area/jeju.jsp')
      .then((response) => response.text())
      .then((data) => {
        document.getElementById('result').innerHTML = data;
      });
  } else {
    document.getElementById('result').innerHTML = '';
  }
}
