var loginOut = function() {
	var btnLogin = document.getElementById('btnLogin');
	
	if(btnLogin != null) {
		btnLogin.onclick = function() {
			var frm = document.from_log;
			frm.action="<%=request.getContextPath() %>/login/login.jsp";
			frm.submit();
		}
	}
	
	var btnLogout = document.getElementById('btnLogout');
	
	if(btnLogout != null) {
		btnLogout.onclick = function() {
			if(confirm("정말 로그아웃 하시겠습니까?")){
				alert("로그아웃되었습니다.");
				location.href='<%=request.getContextPath() %>/login/logout.jsp';
			}
		}
	}
}