package user;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UserDAO {
	private Connection conn; //db 접근 객체 
	private PreparedStatement pstmt;
	private ResultSet rs; // db 결과를 담는 객체
	
	public UserDAO() { // dao 생성자에서 db connection 
		try {
			String JDBC_DRIVER = "org.gjt.mm.mysql.Driver";
			String dbURL = "jdbc:mysql://localhost:3306/BBS"; //mySQL 서버의 BBS DB 접근 경로
			String dbID = "root"; //계정
			String dbPassword = "0322"; //비밀번호
			Class.forName("com.mysql.jdbc.Driver"); //mysql에 접속을 도와주는 라이브러리 
			conn = DriverManager.getConnection(dbURL, dbID, dbPassword);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	// 로그인 기능 
	public int login(String userID, String userPassword) {
		String SQL = "SELECT userPassword FROM USER WHERE userID = ?";
		try {
			pstmt = conn.prepareStatement(SQL);
			pstmt.setString(1, userID); //sql Injection 공격 방어 수단 : 1번째 물음표에 userID 입력
			rs = pstmt.executeQuery(); // 쿼리 실행 
			if (rs.next()) {
				if (rs.getString(1).equals(userPassword)) // rs.getString(1) : select된 첫번째 컬럼
					return 1; //로그인 성공
				else
					return 0; // 비밀번호 틀림
			}
			return -1; // 아이디 없음 
		}catch(Exception e) {
			e.printStackTrace();
		}
		return -2; //DB 오류 
	}
	
	//회원가입 기능
	public int join(User user) {
		 String userId = user.getUserID();

		 // 이미 존재하는 아이디인지 확인하는 로직을 구현합니다.
		 if (isIdExists(userId)) {
		     return -1; // 이미 존재하는 아이디인 경우 -1을 반환합니다.
		 }
		    
		String SQL = "INSERT INTO USER VALUES(?, ?, ?, ?, ?)";
		try {
			pstmt = conn.prepareStatement(SQL);
			pstmt.setString(1, user.getUserID());
			pstmt.setString(2, user.getUserPassword());
			pstmt.setString(3, user.getUserName());
			pstmt.setString(4, user.getUserEmail());
			pstmt.setString(5, user.getUserAdmin());
			return pstmt.executeUpdate(); // 0이상 값이 return된 경우 성공 
		}catch(Exception e) {
			e.printStackTrace();
			
		}
		return -1; //DB 오류 
	}
	
	//아이디 중복여부를 검사하는 메소드
	private boolean isIdExists(String userId) {
		String SQL = "SELECT * FROM USER WHERE userID = ?";
	    try {
	        pstmt = conn.prepareStatement(SQL);
	        pstmt.setString(1, userId);
	        ResultSet rs = pstmt.executeQuery();
	        if (rs.next()) {
	        	int count = rs.getInt(1);
	            // 이미 존재하는 아이디인 경우 count 값이 1 이상일 것입니다.
	            return count >= 1;
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    return false; // 존재하지 않는 아이디인 경우 false를 반환합니다.
	}
	
	
}