package user;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.cj.xdevapi.Statement;

public class MVCBoardDao {
	/*
	private Connection conn; //db 접근 객체 
	private PreparedStatement pstmt;
	private ResultSet rs; // db 결과를 담는 객체
	
	public MVCBoardDao() { // dao 생성자에서 db connection 
		try {
			String JDBC_DRIVER = "org.gjt.mm.mysql.Driver";
			String dbURL = "jdbc:mysql://localhost:3306/BBS"; //mySQL 서버의 BBS DB 접근 경로
			String dbID = "root"; //계정
			String dbPassword = "0322"; //비밀번호
			Class.forName("com.mysql.jdbc.Driver"); //mysql에 접속을 도와주는 라이브러리 
			conn = DriverManager.getConnection(dbURL, dbID, dbPassword);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	*/
	
	//게시글 전체 출력
	public List<MVCBoardDto> selectAll(){
		Connection conn = null; //db 접근 객체 
		PreparedStatement pstmt = null;
		ResultSet rs = null; // db 결과를 담는 객체
		
		try {
			String JDBC_DRIVER = "org.gjt.mm.mysql.Driver";
			String dbURL = "jdbc:mysql://localhost:3306/BBS"; //mySQL 서버의 BBS DB 접근 경로
			String dbID = "root"; //계정
			String dbPassword = "0322"; //비밀번호
			Class.forName("com.mysql.jdbc.Driver"); //mysql에 접속을 도와주는 라이브러리 
			conn = DriverManager.getConnection(dbURL, dbID, dbPassword);
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		java.sql.Statement stmt= null;
		List<MVCBoardDto> res= new ArrayList<MVCBoardDto>();
		
		String sql = "select * from MVCBOARD";
		
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			
			while(rs.next()) {
				MVCBoardDto tmp = new MVCBoardDto();
				tmp.setBd_no(rs.getString(1));
				tmp.setBd_name(rs.getString(2));
				tmp.setBd_title(rs.getString(3));
				tmp.setBd_content(rs.getString(4));
				tmp.setBd_date(rs.getDate(5));
				
				res.add(tmp);
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				rs.close();
				stmt.close();
				conn.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		return res;
	}
	
	public MVCBoardDto selectOne(int bd_no) {
		return null;
	}
	
	public int insert(MVCBoardDto dto) {
		return 0;
	}
	
	public int update(MVCBoardDto dto) {
		return 0;
	}
	
	public int delete(int bd_no) {
		return 0;
	}
	
	public int multiDelete(String[] bd_no) {
		return 0;
	}
}
